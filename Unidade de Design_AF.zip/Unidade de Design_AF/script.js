// ============================================================
// SISTEMA DE GESTÃO DE DESIGN - SCRIPT COMPLETO
// ============================================================

// ========== CONSTANTES ==========
const STORAGE_KEYS = {
    PROCESSOS: 'sgd_processos',
    TECNICOS: 'sgd_tecnicos',
    VERSOES: 'sgd_versoes',
    INTERVENIENTES: 'sgd_intervenientes',
    HISTORICO: 'sgd_historico'
};

// ========== ESTADOS POSSÍVEIS ==========
const ESTADOS = [
    'Recebido', 'Em Análise', 'Em Planeamento', 'Atribuído',
    'Em Desenvolvimento', 'Em Revisão', 'Aguardando Validação',
    'Aguardando Aprovação', 'Aprovado', 'Concluído', 'Cancelado'
];

const PRIORIDADES = ['Baixa', 'Média', 'Alta', 'Urgente'];

// ========== DADOS INICIAIS ==========
function getDadosIniciais() {
    const hoje = new Date().toLocaleDateString('pt-BR');
    const mes = new Date().getMonth() + 1;
    const ano = new Date().getFullYear();
    
    return {
        processos: [
            {
                id: 'DESIGN-2026-001',
                dataEntrada: '15/08/2026',
                area: 'DCCN',
                responsavel: 'João Silva',
                tipo: 'Identidade Visual',
                descricao: 'Criação logo institucional',
                objetivo: 'Modernizar marca',
                requisitos: 'Cores: azul e cinza, formato horizontal',
                prioridade: 'Alta',
                prazo: '15/09/2026',
                tecnico: 'Ana Oliveira',
                estado: 'Em Desenvolvimento',
                dataConclusao: '',
                observacoes: 'Briefing aprovado'
            },
            {
                id: 'DESIGN-2026-002',
                dataEntrada: '20/08/2026',
                area: 'UPDNN',
                responsavel: 'Maria Santos',
                tipo: 'Layout Inovação',
                descricao: 'Layout nova embalagem',
                objetivo: 'Reduzir custos',
                requisitos: 'Sustentável, tamanho M',
                prioridade: 'Média',
                prazo: '20/09/2026',
                tecnico: 'Carlos Lima',
                estado: 'Aguardando Validação',
                dataConclusao: '',
                observacoes: 'Protótipo enviado'
            },
            {
                id: 'DESIGN-2026-003',
                dataEntrada: '01/08/2026',
                area: 'Comunicação',
                responsavel: 'Pedro Costa',
                tipo: 'Material Promocional',
                descricao: 'Flyer campanha verão',
                objetivo: 'Aumentar vendas',
                requisitos: 'Formato A5, 4 cores',
                prioridade: 'Urgente',
                prazo: '10/08/2026',
                tecnico: 'Ana Oliveira',
                estado: 'Concluído',
                dataConclusao: '05/08/2026',
                observacoes: 'Aprovado com ajustes'
            },
            {
                id: 'DESIGN-2026-004',
                dataEntrada: '25/08/2026',
                area: 'RH',
                responsavel: 'Carla Dias',
                tipo: 'Manual Produto',
                descricao: 'Manual de onboarding',
                objetivo: 'Padronizar treinamentos',
                requisitos: 'Incluir infográficos',
                prioridade: 'Baixa',
                prazo: '25/10/2026',
                tecnico: '',
                estado: 'Recebido',
                dataConclusao: '',
                observacoes: 'Aguardando briefing'
            },
            {
                id: 'DESIGN-2026-005',
                dataEntrada: '28/08/2026',
                area: 'DCCN',
                responsavel: 'António Ferreira',
                tipo: 'Protótipo',
                descricao: 'Protótipo nova embalagem',
                objetivo: 'Testar usabilidade',
                requisitos: 'Material reciclável',
                prioridade: 'Alta',
                prazo: '15/10/2026',
                tecnico: 'Beatriz Sousa',
                estado: 'Em Análise',
                dataConclusao: '',
                observacoes: 'Aguardando especificações'
            }
        ],
        tecnicos: [
            { id: 'T001', nome: 'Ana Oliveira', email: 'ana@design.com', especialidade: 'Identidade Visual, Layout', ativo: true },
            { id: 'T002', nome: 'Carlos Lima', email: 'carlos@design.com', especialidade: 'Prototipagem, 3D', ativo: true },
            { id: 'T003', nome: 'Beatriz Sousa', email: 'beatriz@design.com', especialidade: 'Motion Design, UI/UX', ativo: true },
            { id: 'T004', nome: 'Rafael Mendes', email: 'rafael@design.com', especialidade: 'Design Editorial', ativo: true }
        ],
        versoes: [
            { id: 'V001', processo: 'DESIGN-2026-001', numero: 'v1.0', data: '18/08/2026', responsavel: 'Ana Oliveira', alteracoes: 'Proposta inicial', estado: 'Desenvolvimento' },
            { id: 'V002', processo: 'DESIGN-2026-001', numero: 'v2.0', data: '22/08/2026', responsavel: 'Ana Oliveira', alteracoes: 'Ajustes cores e tipografia', estado: 'Revisão' },
            { id: 'V003', processo: 'DESIGN-2026-002', numero: 'v1.0', data: '25/08/2026', responsavel: 'Carlos Lima', alteracoes: 'Protótipo funcional', estado: 'Final' },
            { id: 'V004', processo: 'DESIGN-2026-003', numero: 'v1.0', data: '02/08/2026', responsavel: 'Ana Oliveira', alteracoes: 'Layout inicial', estado: 'Aprovada' },
            { id: 'V005', processo: 'DESIGN-2026-003', numero: 'v2.0', data: '04/08/2026', responsavel: 'Ana Oliveira', alteracoes: 'Correções cliente', estado: 'Final' }
        ],
        historico: [
            { data: '15/08/2026 09:30', processo: 'DESIGN-2026-001', acao: 'Criação', usuario: 'João Silva', detalhes: 'Nova solicitação', estadoAnterior: '-', estadoNovo: 'Recebido' },
            { data: '18/08/2026 14:20', processo: 'DESIGN-2026-001', acao: 'Atribuição', usuario: 'Gestor', detalhes: 'Técnico: Ana Oliveira', estadoAnterior: 'Em Planeamento', estadoNovo: 'Atribuído' },
            { data: '22/08/2026 16:45', processo: 'DESIGN-2026-001', acao: 'Versão', usuario: 'Ana Oliveira', detalhes: 'v2.0 criada', estadoAnterior: 'Em Desenvolvimento', estadoNovo: 'Em Revisão' }
        ]
    };
}

// ========== FUNÇÕES DE ACESSO AO STORAGE ==========
function carregarDados() {
    let dados = {};
    
    for (let key in STORAGE_KEYS) {
        const value = localStorage.getItem(STORAGE_KEYS[key]);
        dados[key] = value ? JSON.parse(value) : [];
    }
    
    // Verificar se há dados, se não, carregar dados iniciais
    if (dados.processos.length === 0) {
        const iniciais = getDadosIniciais();
        dados = iniciais;
        salvarDados(dados);
    }
    
    return dados;
}

function salvarDados(dados) {
    for (let key in STORAGE_KEYS) {
        if (dados[key] !== undefined) {
            localStorage.setItem(STORAGE_KEYS[key], JSON.stringify(dados[key]));
        }
    }
}

function getProcessos() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.PROCESSOS) || '[]');
}

function setProcessos(processos) {
    localStorage.setItem(STORAGE_KEYS.PROCESSOS, JSON.stringify(processos));
}

function getTecnicos() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.TECNICOS) || '[]');
}

function setTecnicos(tecnicos) {
    localStorage.setItem(STORAGE_KEYS.TECNICOS, JSON.stringify(tecnicos));
}

function getVersoes() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.VERSOES) || '[]');
}

function setVersoes(versoes) {
    localStorage.setItem(STORAGE_KEYS.VERSOES, JSON.stringify(versoes));
}

function getHistorico() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORICO) || '[]');
}

function setHistorico(historico) {
    localStorage.setItem(STORAGE_KEYS.HISTORICO, JSON.stringify(historico));
}

// ========== FUNÇÕES AUXILIARES ==========
function gerarId(prefixo) {
    const data = new Date();
    const ano = data.getFullYear();
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const dia = String(data.getDate()).padStart(2, '0');
    return `${prefixo}-${ano}${mes}${dia}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;
}

function dataAtual() {
    return new Date().toLocaleDateString('pt-BR');
}

function dataHoraAtual() {
    return new Date().toLocaleString('pt-BR');
}

function formatarData(data) {
    if (!data) return '';
    const d = new Date(data);
    return d.toLocaleDateString('pt-BR');
}

function getDiasRestantes(prazo) {
    if (!prazo) return '';
    const hoje = new Date();
    const prazoDate = new Date(prazo.split('/').reverse().join('-'));
    const diff = Math.ceil((prazoDate - hoje) / (1000 * 60 * 60 * 24));
    return diff;
}

function getStatusPrazo(prazo, estado) {
    if (estado === 'Concluído' || estado === 'Cancelado') return 'Concluído';
    const dias = getDiasRestantes(prazo);
    if (dias < 0) return 'ATRASADO';
    if (dias === 0) return 'VENCE HOJE';
    if (dias <= 3) return 'PRÓXIMO';
    return 'DENTRO DO PRAZO';
}

function getBadgeEstado(estado) {
    const mapa = {
        'Recebido': 'recebido',
        'Em Análise': 'analise',
        'Em Planeamento': 'planeamento',
        'Atribuído': 'atribuido',
        'Em Desenvolvimento': 'desenvolvimento',
        'Em Revisão': 'revisao',
        'Aguardando Validação': 'validacao',
        'Aguardando Aprovação': 'aprovacao',
        'Aprovado': 'aprovado',
        'Concluído': 'concluido',
        'Cancelado': 'cancelado'
    };
    return `badge badge-${mapa[estado] || 'recebido'}`;
}

function getBadgePrioridade(prioridade) {
    const mapa = {
        'Urgente': 'urgente',
        'Alta': 'alta',
        'Média': 'media',
        'Baixa': 'baixa'
    };
    return `badge-prioridade badge-${mapa[prioridade] || 'baixa'}`;
}

// ========== INICIALIZAÇÃO ==========
let dadosCache = null;

function inicializar() {
    dadosCache = carregarDados();
    atualizarTudo();
    configurarEventos();
    configurarNavegacao();
    document.getElementById('dataAtual').textContent = new Date().toLocaleDateString('pt-BR', { 
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' 
    });
}

function configurarNavegacao() {
    document.querySelectorAll('.menu-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.menu-btn').forEach(b => b.classList.remove('ativo'));
            this.classList.add('ativo');
            
            const tab = this.dataset.tab;
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('ativo'));
            document.getElementById(tab).classList.add('ativo');
        });
    });
}

function configurarEventos() {
    // Formulário de Processo
    document.getElementById('form-processo').addEventListener('submit', function(e) {
        e.preventDefault();
        salvarProcesso();
    });
}

// ========== DASHBOARD ==========
function atualizarDashboard() {
    const processos = getProcessos();
    const total = processos.length;
    const concluidos = processos.filter(p => p.estado === 'Concluído').length;
    const andamento = processos.filter(p => p.estado !== 'Concluído' && p.estado !== 'Cancelado').length;
    const atrasados = processos.filter(p => p.estado !== 'Concluído' && p.estado !== 'Cancelado' && getStatusPrazo(p.prazo, p.estado) === 'ATRASADO').length;
    const urgentes = processos.filter(p => p.prioridade === 'Urgente').length;
    const taxa = total > 0 ? Math.round((concluidos / total) * 100) : 0;
    
    document.getElementById('kpi-total').textContent = total;
    document.getElementById('kpi-andamento').textContent = andamento;
    document.getElementById('kpi-concluidos').textContent = concluidos;
    document.getElementById('kpi-taxa').textContent = taxa + '%';
    document.getElementById('kpi-atrasados').textContent = atrasados;
    document.getElementById('kpi-urgente').textContent = urgentes;
    document.getElementById('totalProcessos').textContent = total;
    
    // Gráficos
    renderizarGraficoEstados(processos);
    renderizarGraficoPrioridade(processos);
    renderizarGraficoArea(processos);
    renderizarGraficoPrazos(processos);
}

function renderizarGraficoEstados(processos) {
    const container = document.getElementById('chart-estados');
    const estados = {};
    ESTADOS.forEach(e => estados[e] = 0);
    processos.forEach(p => {
        if (estados[p.estado] !== undefined) estados[p.estado]++;
    });
    
    let html = '';
    const total = processos.length || 1;
    for (let [estado, count] of Object.entries(estados)) {
        if (count === 0) continue;
        const pct = Math.round((count / total) * 100);
        html += `
            <div class="chart-bar">
                <span class="chart-label">${estado}</span>
                <div class="chart-track">
                    <div class="chart-fill" style="width: ${pct}%">${count}</div>
                </div>
                <span class="chart-value">${pct}%</span>
            </div>
        `;
    }
    container.innerHTML = html || '<p style="color:#999;">Nenhum dado disponível</p>';
}

function renderizarGraficoPrioridade(processos) {
    const container = document.getElementById('chart-prioridade');
    const prioridades = {};
    PRIORIDADES.forEach(p => prioridades[p] = 0);
    processos.forEach(p => {
        if (prioridades[p.prioridade] !== undefined) prioridades[p.prioridade]++;
    });
    
    let html = '';
    const total = processos.length || 1;
    for (let [prioridade, count] of Object.entries(prioridades)) {
        if (count === 0) continue;
        const pct = Math.round((count / total) * 100);
        const classe = prioridade.toLowerCase();
        html += `
            <div class="chart-bar">
                <span class="chart-label">${prioridade}</span>
                <div class="chart-track">
                    <div class="chart-fill ${classe}" style="width: ${pct}%">${count}</div>
                </div>
                <span class="chart-value">${pct}%</span>
            </div>
        `;
    }
    container.innerHTML = html || '<p style="color:#999;">Nenhum dado disponível</p>';
}

function renderizarGraficoArea(processos) {
    const container = document.getElementById('chart-area');
    const areas = {};
    processos.forEach(p => {
        areas[p.area] = (areas[p.area] || 0) + 1;
    });
    
    let html = '';
    const total = processos.length || 1;
    const sorted = Object.entries(areas).sort((a, b) => b[1] - a[1]);
    for (let [area, count] of sorted) {
        const pct = Math.round((count / total) * 100);
        html += `
            <div class="chart-bar">
                <span class="chart-label">${area}</span>
                <div class="chart-track">
                    <div class="chart-fill" style="width: ${pct}%">${count}</div>
                </div>
                <span class="chart-value">${pct}%</span>
            </div>
        `;
    }
    container.innerHTML = html || '<p style="color:#999;">Nenhum dado disponível</p>';
}

function renderizarGraficoPrazos(processos) {
    const container = document.getElementById('chart-prazos');
    const status = { 'DENTRO DO PRAZO': 0, 'PRÓXIMO': 0, 'VENCE HOJE': 0, 'ATRASADO': 0, 'Concluído': 0 };
    
    processos.forEach(p => {
        const s = getStatusPrazo(p.prazo, p.estado);
        status[s] = (status[s] || 0) + 1;
    });
    
    let html = '';
    const total = processos.length || 1;
    const cores = {
        'DENTRO DO PRAZO': '2e7d32',
        'PRÓXIMO': 'f57c00',
        'VENCE HOJE': 'e65100',
        'ATRASADO': 'c62828',
        'Concluído': '1b5e20'
    };
    const labels = {
        'DENTRO DO PRAZO': '✅ No Prazo',
        'PRÓXIMO': '⚠️ Próximo',
        'VENCE HOJE': '🔴 Vence Hoje',
        'ATRASADO': '🚨 Atrasado',
        'Concluído': '✅ Concluído'
    };
    
    for (let [key, count] of Object.entries(status)) {
        if (count === 0) continue;
        const pct = Math.round((count / total) * 100);
        const cor = cores[key] || '1a237e';
        html += `
            <div class="chart-bar">
                <span class="chart-label">${labels[key] || key}</span>
                <div class="chart-track">
                    <div class="chart-fill" style="width: ${pct}%; background: #${cor}">${count}</div>
                </div>
                <span class="chart-value">${pct}%</span>
            </div>
        `;
    }
    container.innerHTML = html || '<p style="color:#999;">Nenhum dado disponível</p>';
}

// ========== PROCESSOS ==========
function listarProcessos(filtros = {}) {
    const processos = getProcessos();
    const tbody = document.getElementById('tabela-processos-body');
    
    let filtrados = processos;
    
    if (filtros.estado) {
        filtrados = filtrados.filter(p => p.estado === filtros.estado);
    }
    if (filtros.prioridade) {
        filtrados = filtrados.filter(p => p.prioridade === filtros.prioridade);
    }
    if (filtros.busca) {
        const busca = filtros.busca.toLowerCase();
        filtrados = filtrados.filter(p => 
            p.id.toLowerCase().includes(busca) ||
            p.descricao.toLowerCase().includes(busca) ||
            p.responsavel.toLowerCase().includes(busca)
        );
    }
    
    if (filtrados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:30px;color:#999;">Nenhum processo encontrado</td></tr>`;
        return;
    }
    
    let html = '';
    filtrados.forEach(p => {
        const statusPrazo = getStatusPrazo(p.prazo, p.estado);
        const statusLabel = {
            'DENTRO DO PRAZO': '✅ OK',
            'PRÓXIMO': '⚠️ Próx',
            'VENCE HOJE': '🔴 Hoje',
            'ATRASADO': '🚨 Atrasado',
            'Concluído': '✅ Concl.'
        }[statusPrazo] || statusPrazo;
        
        html += `
            <tr>
                <td><strong>${p.id}</strong></td>
                <td>${p.dataEntrada}</td>
                <td>${p.area}</td>
                <td>${p.tipo}</td>
                <td>${p.descricao.substring(0, 30)}${p.descricao.length > 30 ? '...' : ''}</td>
                <td><span class="${getBadgePrioridade(p.prioridade)}">${p.prioridade}</span></td>
                <td>${p.prazo}</td>
                <td>${p.tecnico || '-'}</td>
                <td><span class="${getBadgeEstado(p.estado)}">${p.estado}</span></td>
                <td>${statusLabel}</td>
                <td>
                    <button class="btn-acao btn-editar" onclick="editarProcesso('${p.id}')">✏️</button>
                    <button class="btn-acao btn-avancar" onclick="avancarEstado('${p.id}')">⏩</button>
                    <button class="btn-acao btn-excluir" onclick="excluirProcesso('${p.id}')">🗑️</button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

function aplicarFiltros() {
    const estado = document.getElementById('filtro-estado').value;
    const prioridade = document.getElementById('filtro-prioridade').value;
    const busca = document.getElementById('filtro-busca').value;
    
    listarProcessos({ estado, prioridade, busca });
}

function limparFiltros() {
    document.getElementById('filtro-estado').value = '';
    document.getElementById('filtro-prioridade').value = '';
    document.getElementById('filtro-busca').value = '';
    listarProcessos({});
}

function salvarProcesso() {
    const dados = {
        id: 'DESIGN-' + new Date().getFullYear() + '-' + String(getProcessos().length + 1).padStart(4, '0'),
        dataEntrada: dataAtual(),
        area: document.getElementById('area-solicitante').value,
        responsavel: document.getElementById('responsavel-pedido').value,
        tipo: document.getElementById('tipo-servico').value,
        descricao: document.getElementById('descricao').value,
        objetivo: document.getElementById('objetivo').value,
        requisitos: document.getElementById('requisitos').value,
        prioridade: document.getElementById('prioridade').value,
        prazo: document.getElementById('prazo').value ? new Date(document.getElementById('prazo').value).toLocaleDateString('pt-BR') : '',
        tecnico: document.getElementById('tecnico-responsavel').value,
        estado: 'Recebido',
        dataConclusao: '',
        observacoes: ''
    };
    
    // Validar campos obrigatórios
    if (!dados.area || !dados.responsavel || !dados.tipo || !dados.descricao || !dados.prazo) {
        alert('Por favor, preencha todos os campos obrigatórios (*)');
        return;
    }
    
    const processos = getProcessos();
    processos.push(dados);
    setProcessos(processos);
    
    // Adicionar ao histórico
    adicionarHistorico(dados.id, 'Criação', 'Sistema', 'Nova solicitação criada', '-', 'Recebido');
    
    // Limpar formulário
    document.getElementById('form-processo').reset();
    
    alert('✅ Processo criado com sucesso!');
    atualizarTudo();
    document.querySelector('[data-tab="processos"]').click();
}

function editarProcesso(id) {
    const processos = getProcessos();
    const p = processos.find(p => p.id === id);
    if (!p) return;
    
    // Implementar edição (pode ser um modal ou redirecionar)
    // Por simplicidade, vamos mostrar os dados em um alert
    alert(`Editar processo: ${id}\n\n` +
          `Área: ${p.area}\n` +
          `Responsável: ${p.responsavel}\n` +
          `Tipo: ${p.tipo}\n` +
          `Descrição: ${p.descricao}\n` +
          `Prioridade: ${p.prioridade}\n` +
          `Prazo: ${p.prazo}\n` +
          `Técnico: ${p.tecnico || 'Não atribuído'}\n` +
          `Estado: ${p.estado}\n\n` +
          `(Funcionalidade em desenvolvimento)`);
}

function avancarEstado(id) {
    const processos = getProcessos();
    const p = processos.find(p => p.id === id);
    if (!p) return;
    
    const estados = ESTADOS;
    const idx = estados.indexOf(p.estado);
    
    if (idx === -1 || idx === estados.length - 1) {
        alert('Este processo já está no estado final.');
        return;
    }
    
    const novoEstado = estados[idx + 1];
    const estadoAnterior = p.estado;
    p.estado = novoEstado;
    
    if (novoEstado === 'Concluído') {
        p.dataConclusao = dataAtual();
    }
    
    setProcessos(processos);
    adicionarHistorico(id, 'Avanço de Estado', 'Sistema', `Estado alterado de "${estadoAnterior}" para "${novoEstado}"`, estadoAnterior, novoEstado);
    
    atualizarTudo();
    alert(`✅ Estado alterado para "${novoEstado}"`);
}

function excluirProcesso(id) {
    if (!confirm(`Tem certeza que deseja excluir o processo ${id}?`)) return;
    
    let processos = getProcessos();
    processos = processos.filter(p => p.id !== id);
    setProcessos(processos);
    
    atualizarTudo();
}

// ========== TÉCNICOS ==========
function listarTecnicos() {
    const tecnicos = getTecnicos();
    const processos = getProcessos();
    const tbody = document.getElementById('tabela-tecnicos-body');
    
    if (tecnicos.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:#999;">Nenhum técnico cadastrado</td></tr>`;
        return;
    }
    
    let html = '';
    tecnicos.forEach(t => {
        const ativos = processos.filter(p => p.tecnico === t.nome && p.estado !== 'Concluído' && p.estado !== 'Cancelado').length;
        const status = t.ativo ? '✅ Ativo' : '❌ Inativo';
        html += `
            <tr>
                <td>${t.id}</td>
                <td><strong>${t.nome}</strong></td>
                <td>${t.email}</td>
                <td>${t.especialidade || '-'}</td>
                <td>${ativos}</td>
                <td>${status}</td>
                <td>
                    <button class="btn-acao btn-editar" onclick="editarTecnico('${t.id}')">✏️</button>
                    <button class="btn-acao btn-excluir" onclick="excluirTecnico('${t.id}')">🗑️</button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    
    // Atualizar select de técnicos no formulário
    const select = document.getElementById('tecnico-responsavel');
    select.innerHTML = '<option value="">Não atribuído</option>';
    tecnicos.forEach(t => {
        select.innerHTML += `<option value="${t.nome}">${t.nome}</option>`;
    });
}

function cadastrarTecnico() {
    const nome = document.getElementById('nome-tecnico').value.trim();
    const email = document.getElementById('email-tecnico').value.trim();
    const especialidade = document.getElementById('especialidade-tecnico').value.trim();
    
    if (!nome || !email) {
        alert('Por favor, preencha Nome e E-mail');
        return;
    }
    
    const tecnicos = getTecnicos();
    const id = 'T' + String(tecnicos.length + 1).padStart(3, '0');
    
    tecnicos.push({ id, nome, email, especialidade, ativo: true });
    setTecnicos(tecnicos);
    
    document.getElementById('nome-tecnico').value = '';
    document.getElementById('email-tecnico').value = '';
    document.getElementById('especialidade-tecnico').value = '';
    
    atualizarTudo();
    alert('✅ Técnico cadastrado com sucesso!');
}

function editarTecnico(id) {
    alert(`Editar técnico: ${id}\n\n(Funcionalidade em desenvolvimento)`);
}

function excluirTecnico(id) {
    if (!confirm(`Tem certeza que deseja excluir o técnico ${id}?`)) return;
    
    let tecnicos = getTecnicos();
    tecnicos = tecnicos.filter(t => t.id !== id);
    setTecnicos(tecnicos);
    
    atualizarTudo();
}

// ========== VERSÕES ==========
function listarVersoes() {
    const versoes = getVersoes();
    const tbody = document.getElementById('tabela-versoes-body');
    
    if (versoes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:#999;">Nenhuma versão registrada</td></tr>`;
        return;
    }
    
    let html = '';
    versoes.forEach(v => {
        html += `
            <tr>
                <td>${v.id}</td>
                <td>${v.processo}</td>
                <td><strong>${v.numero}</strong></td>
                <td>${v.data}</td>
                <td>${v.responsavel}</td>
                <td>${v.alteracoes || '-'}</td>
                <td><span class="${getBadgeEstado(v.estado)}">${v.estado}</span></td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    
    // Atualizar select de processos
    const select = document.getElementById('versao-processo');
    const processos = getProcessos();
    const currentValue = select.value;
    select.innerHTML = '<option value="">Selecione o Processo</option>';
    processos.forEach(p => {
        select.innerHTML += `<option value="${p.id}">${p.id} - ${p.descricao.substring(0, 30)}</option>`;
    });
    select.value = currentValue;
}

function registrarVersao() {
    const processo = document.getElementById('versao-processo').value;
    const numero = document.getElementById('numero-versao').value.trim();
    const responsavel = document.getElementById('responsavel-versao').value.trim();
    const alteracoes = document.getElementById('alteracoes-versao').value.trim();
    const estado = document.getElementById('estado-versao').value;
    
    if (!processo || !numero || !responsavel) {
        alert('Por favor, preencha Processo, Nº Versão e Responsável');
        return;
    }
    
    const versoes = getVersoes();
    const id = 'V' + String(versoes.length + 1).padStart(3, '0');
    
    versoes.push({
        id,
        processo,
        numero,
        data: dataAtual(),
        responsavel,
        alteracoes,
        estado
    });
    setVersoes(versoes);
    
    adicionarHistorico(processo, 'Nova Versão', responsavel, `Versão ${numero} criada - ${alteracoes}`, '-', '-');
    
    document.getElementById('numero-versao').value = '';
    document.getElementById('responsavel-versao').value = '';
    document.getElementById('alteracoes-versao').value = '';
    
    atualizarTudo();
    alert('✅ Versão registrada com sucesso!');
}

// ========== HISTÓRICO ==========
function adicionarHistorico(processo, acao, usuario, detalhes, estadoAnterior, estadoNovo) {
    const historico = getHistorico();
    historico.push({
        data: dataHoraAtual(),
        processo,
        acao,
        usuario,
        detalhes,
        estadoAnterior: estadoAnterior || '-',
        estadoNovo: estadoNovo || '-'
    });
    setHistorico(historico);
}

// ========== RELATÓRIOS ==========
function atualizarRelatorios() {
    const processos = getProcessos();
    const tecnicos = getTecnicos();
    
    // Relatório por Tipo
    const tipos = {};
    processos.forEach(p => {
        tipos[p.tipo] = (tipos[p.tipo] || 0) + 1;
    });
    let htmlTipo = '';
    const sortedTipos = Object.entries(tipos).sort((a, b) => b[1] - a[1]);
    sortedTipos.forEach(([tipo, count]) => {
        const concluidos = processos.filter(p => p.tipo === tipo && p.estado === 'Concluído').length;
        htmlTipo += `
            <div class="relatorio-linha">
                <span class="label">${tipo}</span>
                <span class="value">${count} (${concluidos} concluídos)</span>
            </div>
        `;
    });
    document.getElementById('relatorio-tipo').innerHTML = htmlTipo || '<p style="color:#999;">Nenhum dado disponível</p>';
    
    // Relatório por Técnico
    let htmlTec = '';
    tecnicos.forEach(t => {
        const atribuidos = processos.filter(p => p.tecnico === t.nome).length;
        const concluidos = processos.filter(p => p.tecnico === t.nome && p.estado === 'Concluído').length;
        const emAndamento = processos.filter(p => p.tecnico === t.nome && p.estado !== 'Concluído' && p.estado !== 'Cancelado').length;
        htmlTec += `
            <div class="relatorio-linha">
                <span class="label">${t.nome}</span>
                <span class="value">${atribuidos} (${emAndamento} em andamento, ${concluidos} concluídos)</span>
            </div>
        `;
    });
    document.getElementById('relatorio-tecnico').innerHTML = htmlTec || '<p style="color:#999;">Nenhum técnico cadastrado</p>';
    
    // Análise de Prazos
    const statusPrazos = { 'DENTRO DO PRAZO': 0, 'PRÓXIMO': 0, 'VENCE HOJE': 0, 'ATRASADO': 0 };
    processos.forEach(p => {
        if (p.estado === 'Concluído' || p.estado === 'Cancelado') return;
        const s = getStatusPrazo(p.prazo, p.estado);
        if (statusPrazos[s] !== undefined) statusPrazos[s]++;
    });
    let htmlPrazos = '';
    for (let [status, count] of Object.entries(statusPrazos)) {
        const label = {
            'DENTRO DO PRAZO': '✅ No Prazo',
            'PRÓXIMO': '⚠️ Próximo',
            'VENCE HOJE': '🔴 Vence Hoje',
            'ATRASADO': '🚨 Atrasado'
        }[status] || status;
        htmlPrazos += `
            <div class="relatorio-linha">
                <span class="label">${label}</span>
                <span class="value">${count}</span>
            </div>
        `;
    }
    document.getElementById('relatorio-prazos').innerHTML = htmlPrazos || '<p style="color:#999;">Nenhum dado disponível</p>';
    
    // Evolução Mensal
    const meses = {};
    processos.forEach(p => {
        const mes = p.dataEntrada.substring(3, 5) + '/' + p.dataEntrada.substring(6, 10);
        meses[mes] = (meses[mes] || 0) + 1;
    });
    let htmlMensal = '';
    const sortedMeses = Object.entries(meses).sort((a, b) => {
        const [diaA, mesA, anoA] = a[0].split('/');
        const [diaB, mesB, anoB] = b[0].split('/');
        return new Date(anoA, mesA-1, diaA) - new Date(anoB, mesB-1, diaB);
    });
    sortedMeses.forEach(([mes, count]) => {
        htmlMensal += `
            <div class="relatorio-linha">
                <span class="label">${mes}</span>
                <span class="value">${count}</span>
            </div>
        `;
    });
    document.getElementById('relatorio-mensal').innerHTML = htmlMensal || '<p style="color:#999;">Nenhum dado disponível</p>';
}

// ========== CONFIGURAÇÕES ==========
function atualizarConfiguracoes() {
    const processos = getProcessos();
    document.getElementById('config-total').textContent = processos.length;
    
    // Estados
    const estados = {};
    ESTADOS.forEach(e => estados[e] = 0);
    processos.forEach(p => {
        if (estados[p.estado] !== undefined) estados[p.estado]++;
    });
    let html = '';
    for (let [estado, count] of Object.entries(estados)) {
        if (count === 0) continue;
        html += `<div class="relatorio-linha"><span class="label">${estado}</span><span class="value">${count}</span></div>`;
    }
    document.getElementById('config-estados').innerHTML = html || '<p style="color:#999;">Nenhum dado disponível</p>';
}

function exportarDados() {
    const dados = {
        processos: getProcessos(),
        tecnicos: getTecnicos(),
        versoes: getVersoes(),
        historico: getHistorico(),
        exportadoEm: new Date().toISOString()
    };
    
    const json = JSON.stringify(dados, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `sgd_dados_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

function importarDados() {
    document.getElementById('importar-arquivo').click();
}

function importarArquivo(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const dados = JSON.parse(e.target.result);
            
            if (dados.processos) setProcessos(dados.processos);
            if (dados.tecnicos) setTecnicos(dados.tecnicos);
            if (dados.versoes) setVersoes(dados.versoes);
            if (dados.historico) setHistorico(dados.historico);
            
            atualizarTudo();
            alert('✅ Dados importados com sucesso!');
        } catch (err) {
            alert('❌ Erro ao importar dados: ' + err.message);
        }
    };
    reader.readAsText(file);
    event.target.value = '';
}

function limparDados() {
    if (!confirm('ATENÇÃO: Isso apagará TODOS os dados. Tem certeza?')) return;
    if (!confirm('Última confirmação: Todos os dados serão permanentemente excluídos.')) return;
    
    localStorage.removeItem(STORAGE_KEYS.PROCESSOS);
    localStorage.removeItem(STORAGE_KEYS.TECNICOS);
    localStorage.removeItem(STORAGE_KEYS.VERSOES);
    localStorage.removeItem(STORAGE_KEYS.INTERVENIENTES);
    localStorage.removeItem(STORAGE_KEYS.HISTORICO);
    
    // Recarregar dados iniciais
    const iniciais = getDadosIniciais();
    salvarDados(iniciais);
    
    atualizarTudo();
    alert('✅ Dados limpos e reiniciados com sucesso!');
}

// ========== ATUALIZAÇÃO GERAL ==========
function atualizarTudo() {
    atualizarDashboard();
    listarProcessos({});
    listarTecnicos();
    listarVersoes();
    atualizarRelatorios();
    atualizarConfiguracoes();
    
    // Atualizar total no header
    const processos = getProcessos();
    document.getElementById('totalProcessos').textContent = processos.length;
}

// ========== INICIAR ==========
document.addEventListener('DOMContentLoaded', inicializar);